/* Standard integers.                                                */
/*                                 John Hartmann 3 Mar 2015 17:11:41 */

/*********************************************************************/
/* Change activity:                                                  */
/* 3 Mar 2015  New header file.                                      */
/*********************************************************************/


#if !defined(_JPH_STDINT_H)
#define _JPH_STDINT_H

/* pcre  brainlessly includes this file, but does not seem to depend */
/* on it.                                                            */

#endif
