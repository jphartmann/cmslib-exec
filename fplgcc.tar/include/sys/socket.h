/* Socket stuff                                                      */
/*                                John Hartmann 11 Jun 2011 15:49:17 */

/*********************************************************************/
/* Change activity:                                                  */
/*11 Jun 2011  New header file.                                      */
/*********************************************************************/


#if !defined(_JPH_SOCKET_H)
   #define _JPH_SOCKET_H
#endif
