/* alloca                                                            */
/*                                John Hartmann 17 Jun 2011 13:23:06 */

/*********************************************************************/
/* Change activity:                                                  */
/*17 Jun 2011  New header file.                                      */
/*********************************************************************/


#if !defined(_JPH_ALLOCA_H)
   #define _JPH_ALLOCA_H

#include <stddef.h>
extern void * alloca(size_t size);

#endif
