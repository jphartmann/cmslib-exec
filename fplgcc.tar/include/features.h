/* Features we enable                                                */
/*                                 John Hartmann 8 Jun 2011 09:41:56 */

/*********************************************************************/
/* Change activity:                                                  */
/* 8 Jun 2011  New header file.                                      */
/*********************************************************************/


#if !defined(_JPH_FEATURES_H)
   #define _JPH_FEATURES_H
#endif
