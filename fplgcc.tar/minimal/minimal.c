/* The smallest possible C program.                                  */
/*                                John Hartmann 15 Jan 2015 08:07:59 */

#include <eplist.h>

int
cmsmain(struct eplist * epl, char (* pl)[8])
{
   return 42;
}
